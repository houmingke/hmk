package com;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException {
		String str = "测试！";
		Class c = Class.forName(str);
		System.out.println(c);
	}
}
