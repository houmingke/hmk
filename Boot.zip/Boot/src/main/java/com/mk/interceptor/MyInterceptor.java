package com.mk.interceptor;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContext;

import com.mk.tools.ServerWhiteListUtil;

/**
 * 拦截器
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * 
 * @author pjw
 * @date 2017年5月31日 下午5:51:37
 */
public class MyInterceptor implements HandlerInterceptor {
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		boolean flag = true;
        // 头攻击检测
        String requestHost = request.getHeader("host");
        if (requestHost != null && !ServerWhiteListUtil.isWhite(requestHost)) {
            response.setStatus(403);
            return false;
        }
		String ip = request.getRemoteAddr();
		long startTime = System.currentTimeMillis();
		request.setAttribute("requestStartTime", startTime);
		HandlerMethod handlerMethod = (HandlerMethod) handler;
		Method method = handlerMethod.getMethod();
		System.out
				.println("用户:" + ip + ",访问目标:"
						+ method.getDeclaringClass().getName() + "."
						+ method.getName());
		// 获取head信息
		String AppKey = request.getHeader("AppKey");
		//System.out.println("--------------------");
		/*
		 * post.addHeader("AppKey", APP_KEY); post.addHeader("Nonce", NONCE);
		 * post.addHeader("CurTime", curTime); post.addHeader("CheckSum",
		 * checkSum); post.addHeader("Content-Type",
		 * "application/x-www-form-urlencoded;charset=utf-8");
		 */
		//获取访问的url地址
		 String requestURI = request.getRequestURI();
		 //session过期要跳转的地址
	     String loginUrl = "toLogin";  
	     String uri = requestURI.substring(requestURI.lastIndexOf("/"));  
		// User user=(User)request.getSession().getAttribute("user");
	     Object user=null;
	     try {
	    	  user=SecurityUtils.getSubject().getPrincipal();
		} catch (Exception e) {
			//e.printStackTrace();
			user=null;
		}
		//Object user = null;
	     System.out.println("访问的URI："+uri+"   访问的用户信息："+user);
		if (null == user) {
			//排除登录地址
			if (uri.startsWith("/toLogin") || uri.startsWith("/captcha.jpg") || uri.startsWith("/")) {  
                return true;  
            } else {  
            	
            	String basepath = request.getScheme() + "://"
            			+ request.getServerName() + ":" + request.getServerPort()
            			+ request.getContextPath() + "/";
            			RequestContext requestContext = new RequestContext(request);			
            			response.setContentType("text/html;charset=UTF-8");
            			String content = "<script>alert('请求过期，请重新登录');if(typeof window.parent != undefined){window.parent.location.href='"+basepath+"';}else{window.location.href='"+basepath+"';}</script>";
            			response.getWriter().print(content);
            			return false;
                // 非法请求 重定向到登录页面  
//                response.sendRedirect(request.getContextPath() + loginUrl);  
//                return false;  
            }  
		} else {
			flag = true;
		}
		return flag;
	}

	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		HandlerMethod handlerMethod = (HandlerMethod) handler;
		Method method = handlerMethod.getMethod();
		long startTime = (Long) request.getAttribute("requestStartTime");
		long endTime = System.currentTimeMillis();
		long executeTime = endTime - startTime;
		// 打印方法执行时间
		if (executeTime > 1000) {
			System.out.println("[" + method.getDeclaringClass().getName() + "."
					+ method.getName() + "] 执行耗时 : " + executeTime + "ms");
		} else {
			System.out.println("[" + method.getDeclaringClass().getSimpleName()+ "." + method.getName() + "] 执行耗时 : "+ executeTime + "ms");
		}
	}

	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {

	}

	/**
	 * 判断是否ajax请求 spring ajax 返回含有 ResponseBody 或者 RestController注解
	 * 
	 * @param handlerMethod
	 *            HandlerMethod
	 * @return 是否ajax请求
	 */
	public static boolean isAjax(HandlerMethod handlerMethod) {
		ResponseBody responseBody = handlerMethod
				.getMethodAnnotation(ResponseBody.class);
		if (null != responseBody) {
			return true;
		}
		RestController restAnnotation = handlerMethod.getBeanType()
				.getAnnotation(RestController.class);
		if (null != restAnnotation) {
			return true;
		}
		return false;
	}
}
