package com.mk.webservice.service;
/**
 * @author HMK
 * @date 2018年11月27日 下午3:56:22
 * targetNamespace:当前类实现接口所在包名称的反序
 * endpointInterface:当前需要实现接口的全路径
 */
@javax.jws.WebService(targetNamespace="http://service.webservice.mk.com/",endpointInterface="com.mk.webservice.service.WebService")
public class WebServiceImpl implements WebService {

	@Override
	public String TestWebService(String param) {
		return "cxf-webservice测试,webservice地址正常";
	}

}
