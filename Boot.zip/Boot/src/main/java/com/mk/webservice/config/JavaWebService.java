package com.mk.webservice.config;

import javax.jws.WebService;
import javax.xml.ws.Endpoint;

/*

import javax.jws.WebService;
import javax.xml.ws.Endpoint;
*//**
 * 纯java代码webservice
 * 注意:这个项目启动这个main方法需要屏蔽cxf的包(应该是会有冲突)
 * @author HMK
 * @date 2018年11月28日 上午10:16:39
 */
@WebService
public class JavaWebService {

	public String webservice(String param){
		return "这是一个简单的webservice";
	}
	
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:9001/service/webservice", new JavaWebService());
		System.out.println("地址发布成功!");
	}
}
