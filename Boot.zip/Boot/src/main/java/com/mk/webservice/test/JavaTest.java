package com.mk.webservice.test;

import com.mk.webservice.webserviceclient.WebService;
import com.mk.webservice.webserviceclient.WebServiceImplService;

/**
 * 用java jdk生成的webservice客户端
 * @author HMK
 * @date 2018年11月28日 上午10:42:29
 */
public class JavaTest {

	public static void main(String[] args) {
		WebServiceImplService service = new WebServiceImplService();
		WebService str=service.getWebServiceImplPort();
		String ret = str.testWebService("ooo");//随便传入一个参数测试
		System.out.println(ret);
	}
}
