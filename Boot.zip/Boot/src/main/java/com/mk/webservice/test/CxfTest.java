package com.mk.webservice.test;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

public class CxfTest {

	public static void main(String[] args) {
		JaxWsDynamicClientFactory jax = JaxWsDynamicClientFactory.newInstance();
		String url = "http://localhost:9999/boot/service/user?wsdl";
		Client client = jax.createClient(url);
		
//		HTTPConduit conduit = (HTTPConduit) client.getConduit();
//		HTTPClientPolicy policy = new HTTPClientPolicy();
//		policy.setConnectionTimeout(10000);//设置连接超时时间(10秒)
//		policy.setReceiveTimeout(11000);//设置接收超时时间
//		conduit.setClient(policy);
		
		try {
			Object[] str = client.invoke("TestWebService", "");
			System.out.println(str[0]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
