package com.mk.webservice.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
/**
 * WebService
 * @author HMK
 * @date 2018年11月27日 下午3:57:07
 */
@javax.jws.WebService
public interface WebService {

	@WebMethod
	String TestWebService(@WebParam(name="param")String param);
}
