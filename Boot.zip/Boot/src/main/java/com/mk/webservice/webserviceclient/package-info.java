@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.webservice.mk.com/")
package com.mk.webservice.webserviceclient;

