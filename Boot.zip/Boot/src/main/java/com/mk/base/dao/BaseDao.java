package com.mk.base.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;



/**
 * 封装BaseDao 暂时封装insert 不用再手动写入?号插入
 * 
 * @Title:
 * @Description:
 * @author pjw
 * @date 2017年6月18日 下午2:23:54
 * @param <T>
 */
public class BaseDao<T> {
	@Autowired
	@Qualifier("commJdbcTemplate")
	protected JdbcTemplate commjdbcTemplate;
	
	// POJO类的实际类型
	Class<T> entityType;

	/**
	 * 
	 * @param jdbcTemplate
	 *            连接池
	 * @param tableName
	 *            表名
	 * @param ct
	 *            实体Class
	 * @param entity
	 *            待插入实体
	 * @return
	 */
	public int insert(final JdbcTemplate jdbcTemplate, String tableName,
			Class<T> ct, T entity) {
		entityType = ct;
		String table = tableName;
		final StringBuilder sql = new StringBuilder();

		sql.append("insert into " + table + "(");
		HashMap<String, Object> map = getChangesForInsert(entity);
		List<String> columns = new ArrayList<String>();
		final List<Object> values = new ArrayList<Object>();
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			String key = (String) entry.getKey();
			Object val = entry.getValue();
			columns.add(key);
			values.add(val);
		}
		for (int i = 0; i < columns.size(); i++) {
			if (i == columns.size() - 1) {
				sql.append(columns.get(i) + ") values(");
			} else {
				sql.append(columns.get(i) + ",");
			}
		}

		for (int i = 0; i < values.size(); i++) {
			if (i == values.size() - 1) {
				sql.append("?)");
			} else {
				sql.append("?,");
			}
		}
		System.out.println("插入语句：" + sql.toString());

		KeyHolder key = new GeneratedKeyHolder();
		final String insertSql = sql.toString();
		int count = jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection con)
					throws SQLException {
				PreparedStatement ps = jdbcTemplate
						.getDataSource()
						.getConnection()
						.prepareStatement(insertSql,
								Statement.RETURN_GENERATED_KEYS);
				for (int i = 0; i < values.size(); i++) {
					ps.setObject(i + 1, values.get(i));
				}
				return ps;
			}
		});// , key
			// return key.getKey().intValue();
		return count;
	}

	/**
	 * 根据ID更新实体数据到数据库
	 * 
	 * @param entity
	 * @param id 需要跟新数据对应的ID
	 */
	public int update(final JdbcTemplate jdbcTemplate, String tableName,
			Class<T> ct, T entity, String id) {
		entityType = ct;
		StringBuilder sql = new StringBuilder();
		sql.append("update " + tableName + " set ");
		HashMap<String, Object> map = getChangesForUpdate(entity);
		List<String> keys = new ArrayList<String>();
		List<Object> values = new ArrayList<Object>();
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			String key = (String) entry.getKey();
			Object val = entry.getValue();
			keys.add(key);
			values.add(val);
		}
		for (int i = 0; i < keys.size(); i++) {
			if (i == keys.size() - 1) {
				sql.append(keys.get(i) + "=? ");
			} else {
				sql.append(keys.get(i) + "=?,");
			}
		}
		sql.append("where id=?");
		System.out.println("更新语句：" + sql.toString());
		values.add(id);
		return jdbcTemplate.update(sql.toString(), setParams(values.toArray()));
	}
	
	/**
	 * 根据ID更新实体数据到数据库
	 * 
	 * @param entity
	 * @param id 需要跟新数据对应的ID
	 * @param field :更新where对应字段名称
	 */
	public int updateFileId(final JdbcTemplate jdbcTemplate, String tableName,
			Class<T> ct, T entity, String id,String field ) {
		entityType = ct;
		StringBuilder sql = new StringBuilder();
		sql.append("update " + tableName + " set ");
		HashMap<String, Object> map = getChangesForUpdate(entity);
		List<String> keys = new ArrayList<String>();
		List<Object> values = new ArrayList<Object>();
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			String key = (String) entry.getKey();
			Object val = entry.getValue();
			keys.add(key);
			values.add(val);
		}
		for (int i = 0; i < keys.size(); i++) {
			if (i == keys.size() - 1) {
				sql.append(keys.get(i) + "=? ");
			} else {
				sql.append(keys.get(i) + "=?,");
			}
		}
		sql.append("where "+field+"=?");
		System.out.println("更新语句：" + sql.toString());
		values.add(id);
		return jdbcTemplate.update(sql.toString(), setParams(values.toArray()));
	}

	/**
	 * 设置查询用的参数列表
	 * 
	 * @param params
	 * @return
	 */
	protected PreparedStatementSetter setParams(final Object[] params) {
		return new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				// TODO Auto-generated method stub
				for (int i = 0; i < params.length; i++) {
					ps.setObject(i + 1, params[i]);
				}
			}
		};
	}

	/**
	 * 返回待插入实体上的所有非空属性值及属性名的Map
	 * 
	 * @param <T>
	 * 
	 * @param entity
	 * @return
	 */
	protected <T> HashMap<String, Object> getChangesForInsert(T entity) {
		Field[] fields = entityType.getDeclaredFields();

		HashMap<String, Object> insertValues = new HashMap<String, Object>();
		try {
			for (Field field : fields) {
				field.setAccessible(true);
				// 跳过id字段
				/*
				 * if ("id".equalsIgnoreCase(field.getName())) continue;
				 */
				Object value = field.get(entity);
				if (value == null||"".equals(value))
					continue;
				insertValues.put(field.getName(), value);
			}
			return insertValues;
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 返回待插入实体上的所有非空属性值及属性名的Map
	 * 
	 * @param <T>
	 * 
	 * @param entity
	 * @return
	 */
	protected <T> HashMap<String, Object> getChangesForUpdate(T entity) {
		Field[] fields = entityType.getDeclaredFields();

		HashMap<String, Object> insertValues = new HashMap<String, Object>();
		try {
			for (Field field : fields) {
				field.setAccessible(true);
				// 跳过id字段
				if ("id".equalsIgnoreCase(field.getName())) continue;
				Object value = field.get(entity);
				if (value == null||"".equals(value))
					continue;
				insertValues.put(field.getName(), value);
			}
			return insertValues;
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
