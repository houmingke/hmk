package com.mk.base.enums;

public enum BizEnum {
	
	/**
	 * 用户管理模板
	 */
	DB_RESOURE_NULL(101,"数据库没有改资源"),
	
	/**
	 * 通用错误
	 * @param code
	 * @param message
	 */
	REQUEST_NULL(5001, "请求参数错误"),
	SESSION_TIMEOUT(5001, "会话超时"),
	SERVER_ERROR(5003, "服务器异常");
	
	BizEnum(int code, String message) {
		this.code = code;
		this.msg = message;
	}
	
	private int code;

	private String msg;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	public static void main(String[] args) {
		System.out.println(BizEnum.DB_RESOURE_NULL.getCode());
		System.out.println(BizEnum.DB_RESOURE_NULL.getMsg());
	}
}

