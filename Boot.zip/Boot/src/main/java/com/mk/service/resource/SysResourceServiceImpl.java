package com.mk.service.resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mk.dao.resource.SysResourceDao;
import com.mk.domain.resource.SysResource;
import com.mk.domain.tree.Tree;
import com.mk.shiro.realm.ShiroUser;

@Service
public class SysResourceServiceImpl implements SysResourceService {
	@Autowired
	SysResourceDao sysResourceDao;
	private static final String RESOURCE_MENU = "0"; // 菜单

	@Override
	public List<Tree> listAllResource(String resource_type, Boolean state) {
		List<SysResource> resourceList = sysResourceDao
				.listAllResource(RESOURCE_MENU);
		List<Tree> trees = getTrees(resourceList,state);
		return trees;
	}

	@Override
	public List<Tree> listAllMenu() {
		List<SysResource> resourceList = sysResourceDao.listAllMenu();

		List<Tree> trees = new ArrayList<Tree>();
		if (resourceList == null) {
			return trees;
		}
		for (SysResource resource : resourceList) {
			Tree tree = new Tree();
			long id = null != resource.getId() ? Long.parseLong(resource
					.getId()) : null;
			tree.setId(id);
			tree.setPid(resource.getPid());
			tree.setText(resource.getName());
			tree.setIconCls(resource.getIconCls()+" icon-blue");
			tree.setAttributes(resource.getUrl());
			tree.setOpenMode(resource.getOpenMode());
			// tree.setState(state ? 1 :
			// Integer.parseInt(resource.getOpened()));
			trees.add(tree);
		}
		return trees;
	}

	@Override
	public List<SysResource> listTreeGrid() {
		return sysResourceDao.listTreeGrid();
	}

	@Override
	public boolean saveResource(SysResource sysResource) {
		return sysResourceDao.saveResource(sysResource);
	}

	@Override
	public boolean removeResource(String id) {
		return sysResourceDao.removeResource(id);
	}

	@Override
	public SysResource getSysResourceById(String id) {
		return sysResourceDao.getSysResourceById(id);
	}

	@Override
	public boolean updateSysResourceById(SysResource sysResource) {
		return sysResourceDao.updateSysResourceById(sysResource);
	}

	@Override
	public List<Tree> listTree(ShiroUser shiroUser) {
		List<Tree> trees = new ArrayList<Tree>();
		//1.判断缓存中是否有角色
		if (shiroUser.getRoles() == null) {
			return trees;
		}
		//2.如果用户名为admin，则拥有所有权限
	/*	if (shiroUser.getLoginName().equals("admin")) {
			List<SysResource> resourceList = sysResourceDao
					.listAllResource(RESOURCE_MENU);
			trees = getTrees(resourceList,false);
			return trees;
		}*/
		//3.用户权限
		List<SysResource> resourceList = sysResourceDao.listRessourceByUserid(shiroUser.getId());
		trees = getTrees(resourceList,false);
		return trees;
	}
	
	@Override
	public List<SysResource> loadtree(ShiroUser shiroUser,String pid) {
		
		Map<String, String> map = new HashMap<>();
		map.put("userid", shiroUser.getId());
		map.put("pid", pid);
		
		List<SysResource> list = sysResourceDao.loadtree(map);
		return list;
	}
	
	
	/**
	 * 
	 * @param resourceList资源列表  
	 * @param state菜单状态 是否打开  true false
	 * @return
	 */
	private List<Tree> getTrees(List<SysResource> resourceList,boolean state){
		List<Tree> trees = new ArrayList<Tree>();
		if (resourceList == null) {
			return trees;
		}
		for (SysResource resource : resourceList) {
			Tree tree = new Tree();
			long id = null != resource.getId() ? Long.parseLong(resource
					.getId()) : null;
			tree.setId(id);
			tree.setPid(resource.getPid());
			tree.setText(resource.getName());
			tree.setIconCls(resource.getIconCls() +" icon-blue");
			tree.setAttributes(resource.getUrl());
			tree.setOpenMode(resource.getOpenMode());
			tree.setState(state ? 1 : Integer.parseInt(resource.getOpened()));
			tree.setShowtext(resource.getDescription());
			trees.add(tree);
		}
		return trees;
	}

}
