package com.mk.service.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mk.dao.user.SysUserDao;
import com.mk.dao.userRole.SysUserRoleDao;
import com.mk.domain.comm.Result;
import com.mk.domain.user.SysUser;
import com.mk.domain.user.vo.SysUserPwdVo;
import com.mk.domain.user.vo.SysUserVo;
import com.mk.domain.userRole.SysUserRole;
import com.mk.tools.Page;
import com.mk.tools.StringUtil;


@Service
public class SysUserServiceImpl implements SysUserService {
	@Autowired
	SysUserDao sysUserDao;
	@Autowired
	SysUserRoleDao sysUserRoleDao;

	@Override
	public Page listSysUser(HashMap<String, Object> hashMap) {
		return sysUserDao.listSysUser(hashMap);
	}

	@Override
	public SysUserVo getSysUserById(String id) {
		return sysUserDao.getSysUserById(id);
	}

	@Override
	public boolean saveSysUser(SysUserVo sysUservo) {
		try {
			// 1.获取user_id
			String user_id = sysUserDao.getUserid();
			sysUservo.setId(user_id);
			// 2.插入用户表
			SysUserServiceImpl serviceImpl = new SysUserServiceImpl();
			SysUser sysUser = serviceImpl.getSysUser(sysUservo);
			//密码加密
			String salt=StringUtil.generateSalt();
			String pwd=StringUtil.generatePwd(sysUser.getPassword(), salt);
			sysUser.setPassword(pwd);
			sysUser.setSalt(salt);
			sysUserDao.saveSysUser(sysUser);
			// 3.插入用户角色中间表
			List<SysUserRole> sysUserRoles = serviceImpl
					.sysUserRoles(sysUservo);
			return sysUserRoleDao.saveUserRole(sysUserRoles);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean removeSysUserById(String ids) {
		try {
			// 1.删除用户对应的角色
			sysUserRoleDao.deleteUserRoleByUserId(ids);
			// 2.删除用户
			return sysUserDao.removeSysUserById(ids);
		} catch (Exception e) {
			return false;
		}

	}

	@Override
	public boolean updateSysUserById(SysUserVo sysUservo) {
		try {
			SysUserServiceImpl serviceImpl = new SysUserServiceImpl();
			// 1.根据用户id删除用户角色中间相应数据
			sysUserRoleDao.deleteUserRoleByUserId(sysUservo.getId());
			// 2.插入用户角色中间表
			List<SysUserRole> sysUserRoles = serviceImpl
					.sysUserRoles(sysUservo);
			sysUserRoleDao.saveUserRole(sysUserRoles);
			// 3.更新用户数据
			SysUser sysUser = serviceImpl.getSysUser(sysUservo);
			//密码加密
			if(sysUser.getPassword()!=null&&!"".equals(sysUser.getPassword())){
				
				String salt=StringUtil.generateSalt();
				String pwd=StringUtil.generatePwd(sysUser.getPassword(), salt);
				sysUser.setPassword(pwd);
				sysUser.setSalt(salt);
			}
			return sysUserDao.updateSysUserById(sysUser);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 组装List<SysUserRole> 用于批量插入
	 * 
	 * @param sysUservo
	 * @return
	 */
	public List<SysUserRole> sysUserRoles(SysUserVo sysUservo) {
		String[] roles = sysUservo.getRoleIds().split(",");
		List<SysUserRole> sysUserRoles = new ArrayList<>();
		for (String role : roles) {
			SysUserRole sysUserRole = new SysUserRole();
			sysUserRole.setUser_id(sysUservo.getId());
			sysUserRole.setRole_id(role);
			sysUserRoles.add(sysUserRole);
		}
		return sysUserRoles;
	}

	/**
	 * 将SysUserVo转成SysUser
	 * 
	 * @param sysUservo
	 * @return
	 */
	public SysUser getSysUser(SysUserVo sysUservo) {
		SysUser sysUser = new SysUser();
		sysUser.setId(sysUservo.getId());
		sysUser.setAge(sysUservo.getAge());
		sysUser.setName(sysUservo.getName());
		sysUser.setOranization_id(sysUservo.getOranization_id());
		sysUser.setPassword(sysUservo.getPassword());
		sysUser.setPhone(sysUservo.getPhone());
		sysUser.setSex(sysUservo.getSex());
		sysUser.setStatus(sysUservo.getStatus());
		sysUser.setUser_type(sysUservo.getUser_type());
		sysUser.setUsername(sysUservo.getUsername());
		return sysUser;
	}

	@Override
	public List<SysUser> getByLoginName(String loginName) {
		return sysUserDao.getByLoginName(loginName);
	}

	@Override
	public Result updatePwd(SysUserPwdVo sysUservo) {
		Result ret=new Result();
		String newpwd=sysUservo.getNewpwd();
		String oldpwd=sysUservo.getOldpwd();
		String repwd=sysUservo.getRepwd();
		if(newpwd==null||!newpwd.equals(repwd)){
			return Result.ret(false, "两次密码不一致");
		}
		//密码加密
		String old=StringUtil.generatePwd(oldpwd, sysUservo.getSalt());
		SysUserVo sys=sysUserDao.getSysUserById(sysUservo.getId());
		if(sys!=null&&old.endsWith(sys.getPassword())){
			String salt=StringUtil.generateSalt();
			String pwd=StringUtil.generatePwd(sysUservo.getNewpwd(), salt);
			String [] str={pwd,salt,sysUservo.getId()};
			 boolean fh=sysUserDao.updateSysUserPwd(str);
			 ret.setSuccess(fh);
			 if(fh){
				 ret.setMsg("修改成功");
			 }else{
				 ret.setMsg("修改失败");
			 }
			
		}else{
			return Result.ret(false, "旧密码输入有误");
		}
		return ret;
	}

	@Override
	public List<SysUser> getByLoginNameUpdate(String username,String ymc) {
		return sysUserDao.getByLoginNameUpdate(username,ymc);
	}
}
