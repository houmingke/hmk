package com.mk.service.user;

import java.util.HashMap;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mk.domain.comm.Result;
import com.mk.domain.user.SysUser;
import com.mk.domain.user.vo.SysUserPwdVo;
import com.mk.domain.user.vo.SysUserVo;
import com.mk.tools.Page;


public interface SysUserService {
	/**
	 * 查询所有的用户信息
	 * 
	 * @return
	 */
	public Page listSysUser(HashMap<String, Object> hashMap);

	/**
	 * 根据ID获取对应的用户信息
	 * 
	 * @param id
	 * @return
	 */
	public SysUserVo getSysUserById(String id);

	/**
	 * 查询用户名是否存在
	 * 
	 * @param loginName
	 * @return
	 */
	public List<SysUser> getByLoginName(String loginName);
	/**
	 * 插入用户信息
	 * 
	 * @param sysRole
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean saveSysUser(SysUserVo sysUservo);

	/**
	 * 根据id删除对应的用户信息
	 * 
	 * @param ids
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean removeSysUserById(String ids);

	/**
	 * 根据id更新用户信息
	 * 
	 * @param sysRole
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean updateSysUserById(SysUserVo sysUservo);
	/**
	 * 
	 * @param sysUservo
	 * @return
	 */

	public Result updatePwd(SysUserPwdVo sysUservo);
	/**
	 * 修改
	 * @param username
	 * @return
	 */
	public List<SysUser> getByLoginNameUpdate(String username,String ymc);

}
