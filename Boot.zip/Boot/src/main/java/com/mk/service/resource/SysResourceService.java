package com.mk.service.resource;

import java.util.List;
import java.util.Map;

import com.mk.domain.resource.SysResource;
import com.mk.domain.tree.Tree;
import com.mk.shiro.realm.ShiroUser;

public interface SysResourceService {
	public List<Tree> listTree(ShiroUser shiroUser);
	
	public List<Tree> listAllResource(String resource_type, Boolean state);

	public List<Tree> listAllMenu();

	public List<SysResource> listTreeGrid();

	public boolean saveResource(SysResource sysResource);

	public boolean removeResource(String id);

	public SysResource getSysResourceById(String id);

	public boolean updateSysResourceById(SysResource sysResource);

	public List<SysResource> loadtree(ShiroUser shiroUser,String pid);
}
