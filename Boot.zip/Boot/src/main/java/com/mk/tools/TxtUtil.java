package com.mk.tools;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import org.apache.log4j.Logger;


/**
 * 
 * @ClassName: TxtUtil 
 * @Description: 文本文件帮助类
 * @author pjw
 * @date 2014-9-13 下午12:06:40
 */
public class TxtUtil {

	static Logger log = Logger.getLogger(TxtUtil.class.getName());
	public static Boolean FileExists(String filePath){
		File file = new File(filePath);
		if (file.isFile() && file.exists()) {
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 判断文件的编码格式
	 * @param fileName :file
	 * @return 文件编码格式
	 * @throws Exception
	 */
	/*public static String codeString(String fileName) throws Exception{  
		String code = config.getDefaultCharacter();
		CodepageDetectorProxy detector = CodepageDetectorProxy.getInstance();
		detector.add(JChardetFacade.getInstance());
		Charset charset = null;

		try {
			charset = detector.detectCodepage(new File(fileName).toURI().toURL());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (charset != null) {
			code=charset.name();
		}
		System.err.println(code);
		return code.toString();  
		//return "UTF-8";  
	}*/
	/**
	 * 获取文件夹下面所有的文件名称(可取的文件夹的名称)
	 * @param pathname
	 * @return
	 */
	public static String[] GetFolderAllFile(String pathname){
		try {
			String files[] = null;
			File file = new File(pathname);
			files = file.list();
			return files;
		} catch (Exception e) {
			log.info("获取文件失败"+e.getMessage());
			return null;
		}
	}
	/**
	 * 获取文件夹下面所有后缀为txt的文件
	 * @param pathname
	 * @return
	 */
	public static ArrayList<String> GetFolderAllTxt(String pathname){
		try {
			ArrayList<String> arrList = new ArrayList<String>();
			String[] str = GetFolderAllFile(pathname);
			for (String string : str) {
				if (string.length()>3 && string.substring(string.length()-3, string.length()).equals("txt")) {
					arrList.add(string);
				}
			}
			return arrList;
		} catch (Exception e) {
			log.info("获取文件失败"+e.getMessage());
			return null;
		}
	}

	/**
	 * 获取文件夹下面所有的文件夹
	 * @param pathname
	 * @return
	 */
	public static ArrayList<String> GetFolderAllChildFolder(String pathname){
		try {
			ArrayList<String> arrlist = new ArrayList<String>();
			String[] str = GetFolderAllFile(pathname);
			for (int i = 0; i < str.length; i++) {
				String path = pathname + "/" +str[i];
				File file = new File(path);
				if (file.isDirectory()) {
					arrlist.add(str[i]);
				}
			}
			return arrlist;
		} catch (Exception e) {
			log.info("获取文件夹失败"+e.getMessage());
			return null;
		}
	}

	
	/** 
	 * 复制单个文件 
	 * @param oldPathFile 准备复制的文件源 
	 * @param newPathFile 拷贝到新绝对路径带文件名 
	 * @return 
	 */  
	public static void copyFile(String oldPathFile,String newPathFile){
		try {  
			newFiles(newPathFile.substring(0,newPathFile.lastIndexOf("/")));
			int bytesum = 0;  
			int byteread = 0;  
			File oldfile = new File(oldPathFile);
			if (oldfile.exists()) { //文件存在时  
				InputStream inStream = new FileInputStream(oldPathFile); //读入原文件  
				FileOutputStream fs = new FileOutputStream(newPathFile);  
				byte[] buffer = new byte[1444];  
				while((byteread = inStream.read(buffer)) != -1){  
					bytesum += byteread; //字节数 文件大小  
					//System.out.println(bytesum);  
					fs.write(buffer, 0, byteread);  
				}  
				inStream.close();  
			}  
		}catch (Exception e) {  
			log.info("复制单个文文件失败"+e.getMessage());
		} 
	}
	/** 
	 * 删除文件 
	 * @param filePathAndName 文本文件完整绝对路径及文件名 
	 * @return Boolean 成功删除返回true遭遇异常返回false 
	 */  
	public static Boolean delFile(String filePathAndName){
		boolean bea = false;  
		try {  
			String filePath = filePathAndName;  
			File myDelFile = new File(filePath);  
			if(myDelFile.exists()){ 
				myDelFile.delete();  
				bea = true;  
			}else{  
				bea = false;  
				//message = (filePathAndName+" 删除文件操作出错");  
			}  
		}  
		catch (Exception e) {  
			log.info("删除文件 失败"+e.getMessage());
		}  
		return bea;  
	}
	/** 
	 * 移动文件 
	 * @param oldPath 
	 * @param newPath 
	 * @return 
	 */ 
	public static void moveFile(String oldPath,String newPath){
		copyFile(oldPath, newPath);  
		delFile(oldPath);  
	}

	/** 
	 * 新建文件  没有则创建 有则追加
	 * @param filePathAndName 文本文件完整绝对路径及文件名 
	 * @param fileContent 文本文件内容 
	 * @param isappend 是否追加文本文件内容 
	 * @return 
	 */  
	public static void createFile(String filePathAndName, String fileContent,boolean isappend) {  
		try {  
			String resultpath =filePathAndName.substring(0,filePathAndName.lastIndexOf("/"));
			newFiles(resultpath);
			String filePath = filePathAndName;  
			filePath = filePath.toString();  
			File myFilePath = new File(filePath);  
			if (!myFilePath.exists()) {  
				myFilePath.createNewFile();  
			}
			FileWriter resultFile = new FileWriter(myFilePath,isappend);  
			PrintWriter myFile = new PrintWriter(resultFile);  
			String strContent = fileContent;  
			myFile.println(strContent);  
			myFile.close();  
			resultFile.close();  
		}  
		catch (Exception e) {  
			log.info("新建文件  没有则创建 有则追加 失败"+e.getMessage());
		}  
	}
	/**
	 * @param filePathAndName 含路径文件名
	 * @param fileContent   写入文件的字符串
	 */
	public static void writeFile(String filePathAndName, String fileContent,boolean isappend) {
		try {
			String resultpath =filePathAndName.substring(0,filePathAndName.lastIndexOf("/"));
			newFiles(resultpath);
			File f = new File(filePathAndName);
			if (!f.exists()) {
				f.createNewFile();
			}
			//定义编码
			OutputStreamWriter write = new OutputStreamWriter(new FileOutputStream(f,isappend), "UTF-8");
			BufferedWriter writer = new BufferedWriter(write);
			writer.write(fileContent);
			writer.close();
		} catch (Exception e) {
			log.info("写文件内容操作出错"+e.getMessage());
		}

	}
	/** 
	 * 新建目录 
	 * @param folderPath 目录 
	 * @return 返回目录创建后的路径 
	 */  
	public static String createFolder(String folderPath) {  
		String txt = folderPath;  
		try {  
			java.io.File myFilePath = new java.io.File(folderPath);  
			txt = folderPath;  
			if (!myFilePath.exists()) {  
				myFilePath.mkdirs();
				System.out.println("创建目录:"+txt+"完成");
			}  
		}  
		catch (Exception e) {  
			log.info("新建目录 出错"+e.getMessage());
		}  
		return txt;  
	}  
	/**
	 * 创建目录
	 * @param path
	 * @return
	 */
	public static boolean newFiles(String path){
		try {
			File file =new File(path);    
			//如果文件夹不存在则创建    
			if  (!file.exists()  && !file.isDirectory())      
			{       
				return file.mkdirs();    
			} else   
			{  
			}  
		} catch (Exception e) {
			log.info("新建目录 出错"+e.getMessage());
			return false;
		}
		return true;
	}
	/** *//**文件重命名 
	    * @param path 文件目录 
	    * @param oldname  原来的文件名 
	    * @param newname 新文件名 
	    */ 
	    public static void renameFile(String path,String oldname,String newname){ 
	        if(!oldname.equals(newname)){//新的文件名和以前文件名不同时,才有必要进行重命名 
	            File oldfile=new File(path+"/"+oldname); 
	            File newfile=new File(path+"/"+newname); 
	            if(!oldfile.exists()){
	                return;//重命名文件不存在
	            }
	            if(newfile.exists())//若在该目录下已经有一个文件和新文件名相同，则不允许重命名 
	                System.out.println(newname+"已经存在！"); 
	            else{ 
	                oldfile.renameTo(newfile); 
	            } 
	        }else{
	            System.out.println("新文件名和旧文件名相同...");
	        }
	    }
	    
	  /*  public static void main(String[] args) {
//	    	String oldname="ds_nsrdjxx_20170602_1497862049222_1001_6.td";
//	    	//				ds_nsrdjxx_20170602_1497862049222_1001_6.tb
//	    	String xgname= "ds_nsrdjxx_20170602_1497862049222_1001_6.txt";
//			TxtUtil.renameFile("E:/TEST/", oldname, xgname);
//			
//	    	Calendar cal1 = Calendar.getInstance();  
//           System.out.println(cal1.get(Calendar.HOUR)); 
	    	Calendar dd = Calendar.getInstance();  
            dd.set(Calendar.HOUR_OF_DAY, 4);
            Calendar ee = Calendar.getInstance();  
            Long sj=dd.getTime().getTime()-ee.getTime().getTime();
            System.out.println(sj);
		}*/
}

