package com.mk.tools.timer;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
public class MyTimer{

	public static void main(String[] args) {
		MyTimer m =new MyTimer();
		m.run();
	}

	public void run() {
		
		new Timer().schedule(new TimerTask() {
			
			@Override
			public void run() {
				Calendar calendar = Calendar.getInstance();
				int day = calendar.get(Calendar.DAY_OF_MONTH);
				int hour = calendar.get(Calendar.HOUR_OF_DAY);
			}
		}, 0, 1000*60);
		
	}
}
