package com.mk.tools.poi.alibaba_easyexcel;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.ss.formula.functions.T;

import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.metadata.Sheet;
import com.mk.domain.alibaba_excel.EasyExcel;

/**
 * alibaba_easyexcel导入
 * @author Hmk
 * 2019年4月8日下午5:04:06
 */
public class Excel_Import_Util {

	public static void main(String[] args) throws Exception {
		/*InputStream inputStream = new BufferedInputStream(new FileInputStream(new File("D:/upload/aaaa.xlsx")));
		//InputStream inputStream = new FileInputStream(new File("D:/upload/aaaa.xlsx"));
		ExcelListener listener = new ExcelListener();
		readExcel(inputStream,listener,EasyExcel.class);
		List<T> list = listener.getDatas();*/
		
		List<T> list = readExcel("D:/upload/aaaa.xlsx",EasyExcel.class);
		System.out.println(list);
		
	}
	
	/**
	 * 读取excel
	 * @param inputStream 文件流
	 * @param listener
	 * @param cl 实体类
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void readExcel(InputStream inputStream,ExcelListener listener,Class cl){
		try {									  //new Sheet(从左到右第1个sheet,第2行读取,实体)
			EasyExcelFactory.readBySax(inputStream, new Sheet(1,1,cl), listener);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(null != inputStream){
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * 读取excel
	 * @param filepath 文件名
	 * @param cl 实体类
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List<T> readExcel(String filepath,Class cl) throws Exception{
		
		InputStream inputStream = new BufferedInputStream(new FileInputStream(new File(filepath)));
		ExcelListener listener = new ExcelListener();
		try {
			//InputStream inputStream = new FileInputStream(new File("D:/upload/aaaa.xlsx"));
			EasyExcelFactory.readBySax(inputStream, new Sheet(1,1,cl), listener);
			return listener.getDatas();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally{
			if(null != inputStream){
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
