package com.mk.tools;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 获取本机ip
 * @author HMK
 * @date 2018年11月26日 下午3:31:32
 */
public class GetLocalHostIp {
	// 获取本机名称和IP
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		InetAddress ia = null;
		try {
			ia = ia.getLocalHost();
			String localname = ia.getHostName();
			String localip = ia.getHostAddress();
			System.out.println("本机名称是：" + localname);
			System.out.println("本机的ip是 ：" + localip);
			getScreen();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	// 获取电脑屏幕信息
	public static void getScreen() {
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) screensize.getWidth();
		int height = (int) screensize.getHeight();
		System.out.println("宽的像素：" + width +"\n高的像素：" + height);
		// 获取屏幕的dpi
		int dpi = Toolkit.getDefaultToolkit().getScreenResolution();
		System.out.println(dpi);
		// 根据dpi和像素，可以计算物理尺寸
		System.out.println("宽：" + width / dpi + "高：" + height / dpi);
	}
}
