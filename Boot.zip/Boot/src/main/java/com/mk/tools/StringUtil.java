package com.mk.tools;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Md5Hash;

/**
 * 字符串处理工具类
 * 
 * @author ouzhb
 */
public class StringUtil extends org.springframework.util.StringUtils {

	/**
	 * 判断字符串是否为null、“ ”、“null”
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isNull(String obj) {
		if (obj == null) {
			return true;
		} else if (obj.toString().trim().equals("")) {
			return true;
		} else if (obj.toString().trim().toLowerCase().equals("null")) {
			return true;
		}

		return false;
	}

	/**
	 * 正则验证是否是数字
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumber(String str) {
		Pattern pattern = Pattern.compile("[+-]?[0-9]+[0-9]*(\\.[0-9]+)?");
		Matcher match = pattern.matcher(str);

		return match.matches();
	}

	/**
	 * 将一个长整数转换位字节数组(8个字节)，b[0]存储高位字符，大端
	 * 
	 * @param l
	 *            长整数
	 * @return 代表长整数的字节数组
	 */
	public static byte[] longToBytes(long l) {
		byte[] b = new byte[8];
		b[0] = (byte) (l >>> 56);
		b[1] = (byte) (l >>> 48);
		b[2] = (byte) (l >>> 40);
		b[3] = (byte) (l >>> 32);
		b[4] = (byte) (l >>> 24);
		b[5] = (byte) (l >>> 16);
		b[6] = (byte) (l >>> 8);
		b[7] = (byte) (l);
		return b;
	}

	/**
	 * <pre class="code">
	 * StringUtils.isBlank(null) = true
	 * StringUtils.isBlank("") = true
	 * StringUtils.isBlank(" ") = true
	 * StringUtils.isBlank("12345") = false
	 * StringUtils.isBlank(" 12345 ") = false
	 * @param cs
	 * @return
	 */
	public static boolean isBlank(final CharSequence cs) {
		return !StringUtil.isNotBlank(cs);
	}

	/**
	 * *
	 * 
	 * <pre>
	 * StringUtils.isNotBlank(null)      = false
	 * StringUtils.isNotBlank("")        = false
	 * StringUtils.isNotBlank(" ")       = false
	 * StringUtils.isNotBlank("bob")     = true
	 * StringUtils.isNotBlank("  bob  ") = true
	 * </pre>
	 * 
	 * @param cs
	 * @return
	 */
	public static boolean isNotBlank(final CharSequence cs) {
		return StringUtil.hasText(cs);
	}

	/**
	 * 生成uuid
	 * 
	 * @return UUID
	 */
	public static String getUUId() {
		return UUID.randomUUID().toString();
	}

	/**
	 * add by pjw 20170726 生成salt
	 * 
	 * @return
	 */
	public static String generateSalt() {
		SecureRandomNumberGenerator secureRandom = new SecureRandomNumberGenerator();
		String hex = secureRandom.nextBytes(3).toHex(); // 一个Byte占两个字节，此处生成的3字节，字符串长度为6
		return hex;
	}
	/**
	 * add by pjw 20170726 生成密码
	 * @param password
	 * @param salt
	 * @return
	 */
	public static String generatePwd(String pwd ,String salt) {
		Md5Hash hash = new Md5Hash(pwd,salt,2);
		return hash.toString();
	}
	/**
	 * 截取ip 端口
	 * @param url
	 * @return
	 */
	public static String[] getIpPort(String url){
		try {
			
			String dd=url.split("//")[1].split("/")[0];
			return dd.split(":");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	 public static String getUUID() {
	    	String s = UUID.randomUUID().toString();
	    	return s.substring(0, 8) + s.substring(9, 13) + s.substring(14, 18)
	    	+ s.substring(19, 23) + s.substring(24);
	    	}
	 
	 public static String tirmObject(Object obj){
		 if(obj!=null&&!"".equals(obj)){
			 return obj.toString().trim();
		 }
		 return "";
	 }
	public static void main(String[] args) {
		System.out.println(StringUtil.getUUID());
		System.out.println(StringUtil.generatePwd("111","111111"));
	}
}
