package com.mk.tools.rabbitmq;

import java.io.IOException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

/**
 * RabbitMQ接收端
 * @author Hmk
 * 2019年3月12日上午11:20:27
 */
public class ReceiveMq {
	private final static String QUEUE_NAME = "aaaa";

    public static void main(String[] args) throws IOException, Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        factory.setPort(5672);
        factory.setUsername("admin");
        factory.setPassword("admin");
        Connection connection = factory.newConnection();
        final Channel channel = connection.createChannel();
        channel.queueDeclare(QUEUE_NAME, false, false, false, null);
        System.out.println(" [*] 等待接收消息中......");
        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties,
                    byte[] body) throws IOException {
                String message = new String(body, "UTF-8");
                System.out.println("接收MQ的消息===>:" + message);
                channel.basicAck(envelope.getDeliveryTag(), false);//业务逻辑处理后手动确认mq接收到消息了,队列会自动删除本消息
            }
        };
        /*
         * 第二个参数表示消息确认是否手动应答,false:消息会一直在队列里面,下次启动重新发
         */
        channel.basicConsume(QUEUE_NAME, false, consumer);
    }
}
