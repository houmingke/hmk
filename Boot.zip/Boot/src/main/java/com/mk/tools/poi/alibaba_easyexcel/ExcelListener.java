package com.mk.tools.poi.alibaba_easyexcel;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;

public class ExcelListener<T> extends AnalysisEventListener<T>{

	private List<T> datas = new ArrayList<>();
	
	/**
	 *解析结束销毁不用的资源
     *注意不要调用datas.clear(),否则getDatas为null
	 */
	@Override
	public void doAfterAllAnalysed(AnalysisContext arg0) {
		
	}

	/**
	 * 每解析一行都会回调invoke()方法
	 */
	@Override
	public void invoke(T arg0, AnalysisContext arg1) {
		//把读取到的数据存入到我们的实体里面
		datas.add(arg0);
	}

	public List<T> getDatas() {
		return datas;
	}

	public void setDatas(List<T> datas) {
		this.datas = datas;
	}

	public void clearDatas(){
		this.datas.clear();
		this.datas = null;
	}

}
