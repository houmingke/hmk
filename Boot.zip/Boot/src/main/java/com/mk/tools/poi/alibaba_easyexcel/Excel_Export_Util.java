package com.mk.tools.poi.alibaba_easyexcel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.formula.functions.T;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.metadata.Table;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.mk.domain.alibaba_excel.EasyExcel;

/**
 *  alibaba_easyexcel导出
 * @author Hmk
 * 2019年4月8日下午5:05:11
 */
public class Excel_Export_Util {

	public static void main(String[] args) {
		
		List<EasyExcel> list= new ArrayList<>();
		list.add(new EasyExcel("aaa","aaa",1,"aaa"));
		export(list,"D:/upload/test.xlsx");
	}
	
	/**
	 * 一个excel多个sheet
	 * @param list
	 * @param filepath
	 */
	public static void export(List<EasyExcel> list,String filepath){
		OutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(filepath);
			ExcelWriter writer = new ExcelWriter(outputStream, ExcelTypeEnum.XLSX, true);
			
			//第一个sheet
			Sheet sheet1 = new Sheet(1,0,EasyExcel.class);
			sheet1.setSheetName("sheet1");
			writer.write(list, sheet1);
			
			//第二个sheet
			Sheet sheet2 = new Sheet(2,0,EasyExcel.class);
			sheet2.setSheetName("sheet2");
			writer.write(list, sheet2);
			
			//第三个sheet
			Sheet sheet3 = new Sheet(3,0,EasyExcel.class);
			sheet3.setSheetName("sheet3");
			writer.write(list, sheet3);
			
			writer.finish();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
            try {
            	outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	}
}
