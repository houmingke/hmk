package com.mk.tools;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


/**
 * 服务器白名单列表
 */
public class ServerWhiteListUtil {
    private static List<String> whiteList = null;;

    static {
        try {
            // 读取白名单列表
            whiteList = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 判断当前host是否在白名单内
     * @param host 待查host
     * @return boolean 是否在白名单内
     */
    public static boolean isWhite(String host) {
        if (whiteList == null || whiteList.size() == 0) {
            return true;
        }
        for (String str : whiteList) {
            if (str != null && str.equals(host)) {
                return true;
            }
        }
        return false;
    }
}