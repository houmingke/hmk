package com.mk.tools;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 以流的方式读取或者写入文件
 * @author Hmk
 * 2019年5月7日下午4:33:45
 */
public class FileStreamUtil {

	public static void main(String[] args){
		getOutputStream("E:/ppp.txt","dsadqjdmsaidji");
		
//		String a=getInputStream("E:/ppp.txt");
//		System.out.println(a);
	}
	
	/**
	 * 写数据到文件
	 * @param filepath 文件路径
	 * @param param 写入文件参数
	 */
	public static void getOutputStream(String filepath,String param){
		/*File dir = new File("E:"+File.separator+"test");
		if(!dir.exists()){
			dir.mkdir();
		}
		File file = new File(dir,"Test.txt");
		if(!file.exists()){
			file.createNewFile();
		}*/
		OutputStream os=null;
		try {
			//第二个参数表示是否向文件中追加数据,默认值为false
			os = new FileOutputStream(filepath,false);
			byte[] b = param.getBytes("UTF-8");
			os.write(b);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(null!=os){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	/**
	 * 读取文件
	 * @param filepath 文件路径
	 * @return
	 */
	public static String getInputStream(String filepath){
		InputStream inputStream =null;
		try {
			inputStream = new BufferedInputStream(new FileInputStream(filepath));
			/*byte[] b = new byte[1024];
			int length=0;
			while ((length=f.read(b))!=-1) {
				System.out.println(new String(b,0,length));
			}*/
			byte[] b = new byte[inputStream.available()];
			inputStream.read(b);
			return new String(b);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			if(null!=inputStream){
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
