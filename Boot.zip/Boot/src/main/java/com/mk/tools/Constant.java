package com.mk.tools;

/**
 * 
 *@Title:
 *@Description:
 * @author pjw
 * @date 2017年6月5日 上午11:35:29
 */
public class Constant {
	/**
	 * 数据库为ORACLE
	 */
	public static final String DatabaseProductNameOracle = "Oracle";
	/**
	 * 数据库为Mysql
	 */
	public static final String DATABASEPRODUCTNAMEMYSQL = "Mysql";
	//public static final String PRODUCES = "application/json;charset=UTF-8";
	public static final String PRODUCES = "text/html;charset=UTF-8";
	public static final String PRODUCES_HTML = "text/html;charset=UTF-8";
}
