package com.mk.tools;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

/**
 * jsonp跨域
 * @author HMK
 * @date 2018年11月23日 下午5:46:29
 */
public class JsonpTool {

	/**
	 * jsonp 跨域
	 * 前端代码:
	 * $.ajax({
			url:'url',
			type:'GET',
			dataType : 'jsonp',
			jsonp : 'callback',
			success:function(data){
				var res = JSON.stringify(data);
				alert(res);
			}
		});
	 * @param callback
	 * @return
	 */
	@RequestMapping("/jsonp")
	@ResponseBody
	public String getdata(@RequestParam("callback") String callback){
		String jsonp="这是jsonp跨域";
		String str = JSON.toJSONString(jsonp);//jsonp返回数据需为json格式
		return callback+"("+str+")";
	}
}
