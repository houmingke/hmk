package com.mk.tools;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * jdbcTemplate 分页工具类
 * 
 * @Title:
 * @Description:
 * @author pjw
 * @date 2017年6月5日 下午12:26:25
 * @param <T>
 */
public class Page<T> {
	// 一页显示的记录数
	private int numPerPage;
	// 记录总数
	private int totalRows;
	// 总页数
	private int totalPages;
	// 当前页码
	private int currentPage;
	// 起始行数
	private int startIndex;
	// 结束行数
	private int lastIndex;
	// 结果集存放List
	private List<T> resultList;

	/**
	 * 分页构造函数 ORACLE MYSQL ....
	 * 
	 * @param sql
	 *            包含筛选条件的sql，但不包含分页相关约束，如order by xx asc
	 * @param currentPage
	 *            当前页
	 * @param numPerPage
	 *            每页记录数
	 * @param jdbcTemplate
	 *            jdbcTemplate实例
	 * @return
	 */
	public Page(String sql, int currentPage, int numPerPage,
			JdbcTemplate jdbcTemplate, Class<T> mappedClass) {
		this(sql, currentPage, numPerPage, jdbcTemplate, mappedClass,
				null);
	}

	public Page(String sql, int currentPage, int numPerPage,
			JdbcTemplate jdbcTemplate, Class<T> mappedClass, Object[] parameters) {
		if (jdbcTemplate == null) {
			throw new IllegalArgumentException("Page.jdbcTemplate is null");
		} else if (sql == null || sql.equals("")) {
			throw new IllegalArgumentException("Page.sql is empty");
		}
		// 获取数据库类型名称
		String DatabaseProductName = Constant.DatabaseProductNameOracle;
		/*try {
			DatabaseProductName = jdbcTemplate.getDataSource().getConnection()
					.getMetaData().getDatabaseProductName();
			System.out.println(DatabaseProductName);
		} catch (SQLException e) {
		}*/
		// 设置每页显示记录数
		setNumPerPage(numPerPage);
		// 设置要显示的页数
		setCurrentPage(currentPage);
		// 计算总记录数SQL
		String totalSQL = getTotalSql(sql, DatabaseProductName);
		// 总记录数
		setTotalRows(jdbcTemplate.queryForObject(totalSQL, Integer.class));
		// 计算总页数
		setTotalPages();
		// 计算起始行数
		setStartIndex();
		// 计算结束行数
		setLastIndex();
		System.out.println("lastIndex=" + lastIndex);
		// 拼装oracle的分页语句 （其他DB修改此处的分页关键词即可）
		String paginationSQL = getPaginationSQL(sql, DatabaseProductName);
		// 装入结果集
		List<T> resultList = null;
		if (parameters != null && parameters.length > 0)
			resultList = jdbcTemplate.query(paginationSQL, parameters,
					new BeanPropertyRowMapper<T>(mappedClass));
		else
			resultList = jdbcTemplate.query(paginationSQL, new BeanPropertyRowMapper<T>(
					mappedClass));
		setResultList(resultList);
	}

	/**
	 * 获取不同数据库的查询总条数sql
	 * 
	 * @param sql
	 * @return
	 */
	private String getTotalSql(String sql, String DatabaseProductName) {
		StringBuffer totalSQL;
		switch (DatabaseProductName) {
		case Constant.DatabaseProductNameOracle:
			totalSQL = new StringBuffer(" select count(1) from ( ");
			totalSQL.append(sql);
			totalSQL.append(" ) ");
			break;
		case Constant.DATABASEPRODUCTNAMEMYSQL:
			totalSQL = new StringBuffer(" SELECT count(*) FROM ( ");
			totalSQL.append(sql);
			totalSQL.append(" ) totalTable ");
			break;
		default:// 默认ORACLE
			totalSQL = new StringBuffer(" select count(1) from ( ");
			totalSQL.append(sql);
			totalSQL.append(" ) ");
			break;
		}

		return totalSQL.toString();
	}

	/**
	 * @see 拼装不同数据库的分页语句 （其他DB修改此处的分页关键词即可）
	 * @param sql
	 * @return
	 */
	private String getPaginationSQL(String sql, String DatabaseProductName) {
		StringBuffer paginationSQL;
		switch (DatabaseProductName) {
		case Constant.DatabaseProductNameOracle:
			paginationSQL = new StringBuffer(" select * from ( ");
			paginationSQL.append(" select row_limit.*,rownum rownum_ from ( ");
			paginationSQL.append(sql);
			paginationSQL.append("　) row_limit where rownum <= " + lastIndex);
			paginationSQL.append(" ) where　rownum_ > " + startIndex);
			break;
		case Constant.DATABASEPRODUCTNAMEMYSQL:
			paginationSQL = new StringBuffer();
			paginationSQL.append(sql);
			paginationSQL.append(" limit " + startIndex + "," + lastIndex);
			break;
		default:// 默认ORACLE
			paginationSQL = new StringBuffer(" select * from ( ");
			paginationSQL.append(" select row_limit.*,rownum rownum_ from ( ");
			paginationSQL.append(sql);
			paginationSQL.append("　) row_limit where rownum <= " + lastIndex);
			paginationSQL.append(" ) where　rownum_ > " + startIndex);
			break;
		}
		return paginationSQL.toString();
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getNumPerPage() {
		return numPerPage;
	}

	public void setNumPerPage(int numPerPage) {
		this.numPerPage = numPerPage;
	}

	public List<T> getResultList() {
		return resultList;
	}

	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}

	public int getTotalPages() {
		return totalPages;
	}

	// 计算总页数
	public void setTotalPages() {
		if (totalRows % numPerPage == 0) {
			this.totalPages = totalRows / numPerPage;
		} else {
			this.totalPages = (totalRows / numPerPage) + 1;
		}
	}

	public int getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(int totalRows) {
		this.totalRows = totalRows;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex() {
		this.startIndex = (currentPage - 1) * numPerPage;
	}

	public int getLastIndex() {
		return lastIndex;
	}

	// 计算结束时候的索引
	public void setLastIndex() {
		System.out.println("totalRows=" + totalRows);
		System.out.println("numPerPage=" + numPerPage);
		if (totalRows < numPerPage) {
			this.lastIndex = totalRows;
		} else if ((totalRows % numPerPage == 0)
				|| (totalRows % numPerPage != 0 && currentPage < totalPages)) {
			this.lastIndex = currentPage * numPerPage;
		} else if (totalRows % numPerPage != 0 && currentPage == totalPages) {// 最后一页
			this.lastIndex = totalRows;
		}
	}
}
