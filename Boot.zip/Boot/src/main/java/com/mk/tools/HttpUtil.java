package com.mk.tools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;

public class HttpUtil {

	public static String post(String SERVER_URL,
			HashMap<String, Object> reqParams, HashMap<String, String> reqHeader)
			throws IOException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost(SERVER_URL);

		// 设置请求的header
		if (reqHeader != null) {
			for (String key : reqHeader.keySet()) {
				post.addHeader(key, reqHeader.get(key));
			}
		}
		// 设置请求参数
		if (reqParams != null) {
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			for (String key : reqParams.keySet()) {
				nameValuePairs.add(new BasicNameValuePair(key, reqParams
						.get(key) + ""));
			}
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "utf-8"));
		}
		// 执行请求
		HttpResponse response = httpclient.execute(post);
		System.out.println("返回状态码：" + response.getStatusLine().getStatusCode());
		String responseEntity = EntityUtils.toString(response.getEntity(),
				"utf-8");
		return responseEntity;
		/*
		 * // 判断是否发送成功，发送成功返回true String code =
		 * JSON.parseObject(responseEntity).getString("code"); if
		 * (code.equals("200")) { return "success"; } return "error";
		 */
	}
	
	public static String post_json(String SERVER_URL,
			JSONObject json, HashMap<String, String> reqHeader)
			throws IOException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost(SERVER_URL);

		// 设置请求的header
		if (reqHeader != null) {
			for (String key : reqHeader.keySet()) {
				post.addHeader(key, reqHeader.get(key));
			}
		}
		// 设置请求参数
		StringEntity params = new StringEntity(json.toString(),"utf-8");
		post.setEntity(params);
		// 执行请求
		HttpResponse response = httpclient.execute(post);
		System.out.println("返回状态码：" + response.getStatusLine().getStatusCode());
		String responseEntity = EntityUtils.toString(response.getEntity(),
				"utf-8");
		return responseEntity;
		/*
		 * // 判断是否发送成功，发送成功返回true String code =
		 * JSON.parseObject(responseEntity).getString("code"); if
		 * (code.equals("200")) { return "success"; } return "error";
		 */
	}

	public static String get(String SERVER_URL,
			HashMap<String, Object> reqParams, HashMap<String, String> reqHeader)
			throws IOException {
		// httpClient
		HttpClient httpClient = new DefaultHttpClient();
		// 设置请求参数
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		if (reqParams != null) {
			for (String key : reqParams.keySet()) {
				nameValuePairs.add(new BasicNameValuePair(key, reqParams
						.get(key) + ""));
			}
		}
		// 转换为键值对
		String str = EntityUtils.toString(new UrlEncodedFormEntity(
				nameValuePairs, Consts.UTF_8));
//		System.out.println(SERVER_URL + "&" + str);
		// get method
		System.out.println("请求参数：\r\n"+SERVER_URL + "?" + str);
		
		HttpGet httpGet = new HttpGet(SERVER_URL + "?" + str);
		// set header
		if (reqHeader != null) {
			for (String key : reqHeader.keySet()) {
				httpGet.addHeader(key, reqHeader.get(key));
			}
		}

		// response
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpGet);
			System.out.println("返回状态码："+response.getStatusLine().getStatusCode());
			int code=response.getStatusLine().getStatusCode();
			if(code!=200){
				return "N";
			}
		} catch (Exception e) {
		}
		
		String temp = "";
		try {
			HttpEntity entity = response.getEntity();
			temp = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
		}

		return temp;
	}
}
