package com.mk.shiro.realm;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mk.dao.userRole.SysUserRoleDao;
import com.mk.domain.user.SysUser;
import com.mk.service.user.SysUserService;


public class UserRealm extends AuthorizingRealm {
	Logger logger = LoggerFactory.getLogger(UserRealm.class);
	@Resource
	private SysUserService sysUserService;
	@Autowired
	SysUserRoleDao sysUserRoleDao;

	/**
	 * 认证信息.(身份验证) : Authentication 是用来验证用户身份
	 * 
	 * @param token
	 * @return
	 * @throws AuthenticationException
	 */
	@SuppressWarnings("rawtypes")
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken token) throws AuthenticationException {
		String username = (String) token.getPrincipal();
		List<SysUser> sysUsers = sysUserService.getByLoginName(username);
		if (sysUsers == null || sysUsers.isEmpty()) {
			return null;
		}
		SysUser sysUser = sysUsers.get(0);
		if (sysUser.getStatus().equals("0")) {// 账号无效
			return null;
		}
		// 读取该用户的url和角色信息
		Map<String, Set> map = sysUserRoleDao.getRescourceUrlByUserid(sysUser
				.getId());
		 Set<String> urls =  map.get("urls");

		Map<String, Set> maproles = sysUserRoleDao.getRoleByUserid(sysUser
				.getId());
		Set<String> roles = maproles.get("roles");
		ShiroUser shiroUser = new ShiroUser(sysUser.getId(), sysUser.getUsername(),sysUser.getSalt(),
				sysUser.getName(), urls);
		shiroUser.setRoles(roles); 

		SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(
				shiroUser, // 用户名
				sysUser.getPassword(), // 密码
				ByteSource.Util.bytes(sysUser.getSalt()),
				getName());
		return authenticationInfo;
	}

	/**
	 * shrio授权
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		logger.info("##################执行Shiro权限认证##################");
		ShiroUser shiroUser = (ShiroUser) principals.getPrimaryPrincipal();
		System.out.println(shiroUser.getUrlSet());
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		info.setRoles(shiroUser.getRoles());
		info.addStringPermissions(shiroUser.getUrlSet());
		return info;
	}

}
