package com.mk.controller.resource;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.mk.domain.comm.Result;
import com.mk.domain.resource.SysResource;
import com.mk.domain.tree.Tree;
import com.mk.service.resource.SysResourceService;
import com.mk.shiro.realm.ShiroUser;
import com.mk.tools.Constant;


@Controller
@RequestMapping("/resource")
public class SysResourceController {
	@Autowired
	SysResourceService sysResourceService;

	@RequestMapping("/manager")
	public String manager(Model model) {
		return "sys/resource/resource";
	}

	/**
	 * 添加资源页
	 * 
	 * @return
	 */
	@GetMapping("/addPage")
	public String addPage() {
		return "sys/resource/resourceAdd";
	}

	@RequestMapping("/addresPage")
	public String addresPage(){
		return "sys/resource/resourceAdd";
	}
	
	@RequestMapping("/daydayup")
	public String daydayup(Model model) {
		return "view/daydayup";
	}

	/**
	 * 菜单页，暂未加权限控制
	 * 
	 * @return
	 */
	@RequestMapping(value = "/tree", produces = Constant.PRODUCES)
	@ResponseBody
	public List<Tree> listTree() {
		Subject subject = SecurityUtils.getSubject();
		ShiroUser shiroUser = (ShiroUser) subject.getPrincipal();
		System.out.println(shiroUser.getId());
		List<Tree> trees = sysResourceService.listTree(shiroUser);
		return trees;
	}

	@ResponseBody
	@RequestMapping(value="loadTree")
	public JSONObject loadTree(HttpServletRequest request){
		JSONObject json = new JSONObject();
		
		Subject subject = SecurityUtils.getSubject();
		ShiroUser shiroUser = (ShiroUser) subject.getPrincipal();
		
		String pid = request.getParameter("id");
		System.out.println("pid=========="+pid);
		
		List<Map<String, Object>> rows = new LinkedList<Map<String,Object>>();
		
		//如果pid为空,则为一级菜单
		if(StringUtils.isBlank(pid)){
			List<SysResource> sys = sysResourceService.loadtree(shiroUser,pid);
			if(sys.size()>0){
				for(SysResource s:sys){
					List<SysResource> listsys = sysResourceService.loadtree(shiroUser,s.getPid());
					Map<String, Object> row = new HashMap<>();
					row.put("id", s.getId());
					row.put("title", s.getName());
					row.put("parentId",0);
					row.put("lazy", true);
					//row.put("key", dept.getId());
					row.put("state", listsys != null && listsys.size() > 0 ? "closed" : "open");
					rows.add(row);
				}
			}
		}else{
			List<SysResource> sys = sysResourceService.loadtree(shiroUser,pid);
			if(sys.size()>0){
				for(SysResource s:sys){
					List<SysResource> listsys = sysResourceService.loadtree(shiroUser,s.getPid());
					Map<String, Object> row = new HashMap<>();
					row.put("id", s.getId());
					row.put("title", s.getName());
					row.put("parentId",0);
					row.put("lazy", true);
					//row.put("key", dept.getId());
					row.put("state", listsys != null && listsys.size() > 0 ? "closed" : "open");
					rows.add(row);
				}
			}
		}
		
		json.put("total", rows.size());
		json.put("rows", rows);
		return json;
	};
	
	/**
	 * 编辑时上级资源
	 * 
	 * @return
	 */
	@RequestMapping(value = "/treecombotree", produces = Constant.PRODUCES)
	@ResponseBody
	public List<Tree> listTreeCombotree() {
		List<Tree> trees = sysResourceService.listAllResource("0", true);
		return trees;
	}

	/**
	 * 查询所有的菜单 ,目前用于授权时使用的
	 */
	@RequestMapping(value = "/allTree", produces = Constant.PRODUCES)
	@ResponseBody
	public List<Tree> allMenu() {
		return sysResourceService.listAllMenu();
	}

	/**
	 * 列表页
	 * 
	 * @return
	 */
	@RequestMapping(value = "/list", produces = Constant.PRODUCES)
	@ResponseBody
	public List<SysResource> listTreeGrid() {
		List<SysResource> resources = sysResourceService.listTreeGrid();
		return resources;
	}

	/**
	 * 添加资源
	 * 
	 * @param resource
	 * @return
	 */
	@RequestMapping(value = "/add", produces = Constant.PRODUCES_HTML)
	@ResponseBody
	public Result add(@Valid SysResource resource) {
		// 选择菜单时将openMode设置为null
		String type = resource.getResource_type();
		if (null != type && type == "0") {
			resource.setOpenMode(null);
		}
		boolean bl = sysResourceService.saveResource(resource);
		Result result = new Result();
		result.setSuccess(bl);
		String msg = bl ? "添加成功" : "添加失败";
		result.setMsg(msg);
		return result;
	}

	/**
	 * DELETE FROM resource WHERE id=? 删除资源
	 */
	@RequestMapping(value ="/delete", produces = Constant.PRODUCES_HTML)
	@ResponseBody
	public Result delete(@Valid String id) {
		boolean bl = sysResourceService.removeResource(id);
		Result result = new Result();
		result.setSuccess(bl);
		String msg = bl ? "删除成功" : "删除失败";
		result.setMsg(msg);
		return result;
	}

	/**
	 * 添加资源
	 * 
	 * @param resource
	 * @return
	 */
	@RequestMapping(value = "/update", produces = Constant.PRODUCES_HTML)
	@ResponseBody
	public Result update(@Valid SysResource resource) {
		// 选择菜单时将openMode设置为null
		String type = resource.getResource_type();
		if (null != type && type == "0") {
			resource.setOpenMode(null);
		}
		boolean bl = sysResourceService.updateSysResourceById(resource);
		Result result = new Result();
		result.setSuccess(bl);
		String msg = bl ? "修改成功" : "修改失败";
		result.setMsg(msg);
		return result;
	}

	/**
	 * 根据Id查询资源
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/editById", produces = Constant.PRODUCES)
	@ResponseBody
	public SysResource editById(String id) {
		SysResource resources = sysResourceService.getSysResourceById(id);
		return resources;
	}
	
	@RequestMapping("editPage")
	public String editPage(Model model, String id) {
		model.addAttribute("resource",
				sysResourceService.getSysResourceById(id));
		return "sys/resource/resourceEdit";
	}
}
