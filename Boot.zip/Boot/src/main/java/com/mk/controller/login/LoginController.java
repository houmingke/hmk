package com.mk.controller.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mk.domain.comm.Result;
import com.mk.tools.Constant;
import com.mk.tools.StringUtil;
import com.mk.tools.captcha.DreamCaptcha;
@Controller
public class LoginController {

    private DreamCaptcha dreamCaptcha = new DreamCaptcha();
    
	/**
	 * 首页
	 * @return
	 */
	@RequestMapping({ "/index" })
	public String index(HttpServletRequest request, Model model) {
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + request.getContextPath();
		model.addAttribute("basePath", basePath);
		//System.out.println(basePath);
		return "index";
	}
	/*@RequestMapping({ "/chart" })
	public String chart(HttpServletRequest request, Model model) {
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + request.getContextPath();
		model.addAttribute("basePath", basePath);
		List<IndexTb> list=new ArrayList<>();
		
		Long zs=0l;
		model.addAttribute("chartlist", list);
		for (int i = 0; i < list.size(); i++) {
			IndexTb tb=list.get(i);
			zs+=tb.getValue();
		}
		model.addAttribute("chartsum",zs);
		String json=JSON.toJSONString(list);
		model.addAttribute("chartjson",json);
		System.out.println(basePath);
		return "view/chars/chart";
	}*/
	
	@RequestMapping({ "/", "/toLogin" })
	public String login(HttpServletRequest request, Model model) {
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + request.getContextPath();
		model.addAttribute("basePath", basePath);
		System.out.println(basePath);
		return "login";
	}

	/**
	 * 图形验证码
	 * 前端代码:
	 * 	<img id="captcha" alt="验证码" src="captcha.jpg" data-src="captcha.jpg?t=1" style="vertical-align:middle;border-radius:4px;width:86px;height:28px;cursor:pointer;" />
	 */
	@GetMapping("captcha.jpg")
	public void captcha(HttpServletRequest request, HttpServletResponse response) {
		dreamCaptcha.generate(request, response);
	}

	/**
	 * 图标
	 * @return
	 */
	@RequestMapping("/icons")
	public String icons() {
		return "icons";
	}

	/**
	 * POST 登录 shiro 写法
	 * 
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return {Object}
	 */
	@RequestMapping(value="/login",produces=Constant.PRODUCES_HTML)
	@ResponseBody
	public Object loginPost(
			HttpServletRequest request,
			HttpServletResponse response,
			String username,
			String password,
			String captcha,
			@RequestParam(value = "rememberMe", defaultValue = "0") Integer rememberMe) {
		
		
		
		String msg;
		if(username!=null&&!"".equals(username)){
//			username = Base64Coder.decodeBase64(username);//加密
			username=username.trim();
		}
		/*if(captcha!=null&&!"".equals(captcha)){
			captcha=captcha.trim();
		}*/
		if (StringUtil.isBlank(username)) {
			msg = "用户名不能为空";
			return Result.ret(false, msg);
		}
		if (StringUtil.isBlank(password)) {
			msg = "密码不能为空";
			return Result.ret(false, msg);
		}
//		password = Base64Coder.decodeBase64(password);//加密
		/*if (StringUtil.isBlank(captcha)) {
			msg = "验证码不能为空";
			return Result.ret(false, msg);
		}*/
		// 校验验证码
		/*if (!dreamCaptcha.validate(request, response, captcha)) {
			msg = "验证码错误";
			return Result.ret(false, msg);
		}*/

		Subject user = SecurityUtils.getSubject();
		UsernamePasswordToken token = new UsernamePasswordToken(username,
				password);
		// 设置记住密码
		token.setRememberMe(1 == rememberMe);
		try {
			user.login(token);
			Result ret=new Result();
			ret.setSuccess(true);
			ret.setMsg("登录成功");
			ret.setObj(request.getContextPath());
			return ret;
		} catch (UnknownAccountException e) {
			msg = "账号不存在！";
			return Result.ret(false, msg);
		} catch (DisabledAccountException e) {
			msg = "账号未启用！";
			return Result.ret(false, msg);
		} catch (IncorrectCredentialsException e) {
			msg = "密码错误！";
			return Result.ret(false, msg);
		} catch (Throwable e) {
			msg = "登录失败";
			return Result.ret(false, msg);
		}
	}

	/**
	 * 退出
	 * 
	 * @return
	 */
	@RequestMapping(value = "signout", produces = Constant.PRODUCES)
	@ResponseBody
	public Result logout() {
		Subject subject = SecurityUtils.getSubject();
		subject.logout();
		return Result.ret(true, "退出成功");
	}

}
