package com.mk.dao.userRole;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.mk.domain.userRole.SysUserRole;


public interface SysUserRoleDao {
	/**
	 * 插入用户角色对应关系
	 * @param sysUserRoles
	 * @return
	 */
	boolean saveUserRole(List<SysUserRole> sysUserRoles);
	/**
	 * 根据用户id删除用户角色对应关系
	 * @param roleId
	 * @return
	 */
	public boolean deleteUserRoleByUserId(String userId);
	
	/**
	 * shrio获取用户对应角色的URL地址
	 * @param userId
	 * @return
	 */
	public Map<String, Set> getRescourceUrlByUserid(String userId);
	/**
	 * shrio获取用户的角色
	 * @param userId
	 * @return
	 */
	public Map<String, Set> getRoleByUserid(String userId);
}
