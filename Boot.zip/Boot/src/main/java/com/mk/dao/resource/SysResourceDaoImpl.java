//package com.mk.dao.resource;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Repository;
//
//import com.mk.base.dao.BaseDao;
//
//
//@Repository
//public class SysResourceDaoImpl implements SysResourceDao {
//	@Autowired
//	@Qualifier("commJdbcTemplate")
//	protected JdbcTemplate commjdbcTemplate;
//	BaseDao<SysResource> baseDao = new BaseDao<>();
//	
//	@Autowired SysRoleResourceDao sysRoleResourceDao;
//
//	@Override
//	public List<SysResource> listRessourceByUserid(String userid) {
//		String sql = "SELECT DISTINCT s.id AS id,s.name, s.url, s.description,s.iconCls, s.pid,  s.seq, s.status,s.openMode,  s.opened, s.resource_type,s.sjbcrq  FROM comm_sys_role r  LEFT JOIN comm_sys_role_resource e    ON r.id = e.role_id LEFT JOIN comm_sys_resource s ON e.resource_id = s.id WHERE r.id IN   (select role_id AS roleId from comm_sys_user_role where user_id = ?)   AND s.resource_type = 0  and s.status=1 and r.status=1 ORDER BY seq";
//		List<SysResource> trees = (List<SysResource>) commjdbcTemplate.query(sql,
//				new BeanPropertyRowMapper<SysResource>(SysResource.class),
//				new Object[] { userid });
//		return trees;
//	}
//	
//	@Override
//	public List<SysResource> listAllResource(String resource_type) {
//		String sql = "SELECT id,name,url,openMode,description,iconcls,pid,seq,status,opened,resource_type AS resourceType FROM comm_sys_resource WHERE resource_type = ? and status=1  ORDER BY seq ";
//		List<SysResource> trees = (List<SysResource>) commjdbcTemplate.query(sql,
//				new BeanPropertyRowMapper<SysResource>(SysResource.class),
//				new Object[] { resource_type });
//		return trees;
//	}
//	
//	@Override
//	public List<SysResource> listAllMenu() {
//		String sql = "SELECT id,name,url,openMode,description,iconcls,pid,seq,status,opened,resource_type AS resourceType FROM comm_sys_resource ORDER BY seq ";
//		List<SysResource> trees = (List<SysResource>) commjdbcTemplate.query(sql,
//				new BeanPropertyRowMapper<SysResource>(SysResource.class));
//		return trees;
//	}
//
//	@Override
//	public List<SysResource> listTreeGrid() {
//		String sql = "SELECT id,name,url,openMode,description,iconcls||' icon-blue' as iconcls,pid,seq,status,opened,resource_type  FROM comm_sys_resource ORDER BY seq";
//		List<SysResource> resources = (List<SysResource>) commjdbcTemplate.query(sql,
//				new BeanPropertyRowMapper<SysResource>(SysResource.class));
//		return resources;
//	}
//
//	@Override
//	public boolean saveResource(SysResource sysResource) {
//		String id = commjdbcTemplate.queryForObject("select seq_comm_sys_resource.nextval from dual", String.class);
//		sysResource.setId(id);
//		int count = baseDao.insert(commjdbcTemplate, "comm_sys_resource", SysResource.class, sysResource);
//		return count >= 1 ? true : false;
//	}
//
//	@Override
//	public boolean removeResource(String id) {
//		//1.角色和资源关系删除
//		sysRoleResourceDao.deleteRoleResourceByResourceId(id);
//		//2.删除资源表叔家
//		String sql = "delete from comm_sys_resource where id in (?)";
//		int count = commjdbcTemplate.update(sql, new Object[] { id });
//		return count >= 1 ? true : false;
//	}
//	@Override
//	public SysResource getSysResourceById(String id) {
//		String sql = "SELECT id,name,url,openMode,description,iconcls,pid,seq,status,opened,resource_type  FROM comm_sys_resource where id = ? ORDER BY seq";
//		SysResource resources =commjdbcTemplate.queryForObject(sql,
//				new BeanPropertyRowMapper<SysResource>(SysResource.class),id);
//		return resources;
//	}
//
//	@Override
//	public boolean updateSysResourceById(SysResource sysResource) {
//		
//		Object[] obj = {sysResource.getName(), sysResource.getResource_type(), sysResource.getUrl(), sysResource.getOpenMode(), sysResource.getIconCls(), sysResource.getSeq(), sysResource.getStatus(), sysResource.getOpened(), sysResource.getPid(), sysResource.getDescription(), sysResource.getId(),};
//		String sql="update comm_sys_resource set name=?, resource_type=?, url=?, openMode=?, iconCls=?, seq=?, status=?, opened=?, pid=?, description=? where id=?";
//		
//		int count = commjdbcTemplate.update(sql, obj);
//		return count >= 1 ? true : false;
//	}
//
//	
//
//	
//	
//}
