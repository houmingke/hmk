package com.mk.dao.user;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mk.base.dao.BaseDao;
import com.mk.base.domain.PageEntity;
import com.mk.domain.user.SysUser;
import com.mk.domain.user.vo.SysUserVo;
import com.mk.tools.Page;
@Repository
public class SysUserDaoImpl implements SysUserDao{
	@Autowired
	@Qualifier("commJdbcTemplate")
	protected JdbcTemplate commjdbcTemplate;
	BaseDao<SysUser> baseDao = new BaseDao<>();
	
	@Override
	public Page listSysUser(HashMap<String, Object> hashMap) {
		PageEntity pageEntity = (PageEntity)hashMap.get("page");
		SysUserVo sysUserVo = (SysUserVo)hashMap.get("sysUserVo");
		StringBuffer sb = new StringBuffer();
		sb.append("where 1=1 ");
		if (null != sysUserVo) {
			if (null != sysUserVo.getName() && !sysUserVo.getName().isEmpty()) {
				sb.append(" and t.name like \'%" +sysUserVo.getName()  +"%\'");
			}
			if (null !=sysUserVo.getOranization_id() && !sysUserVo.getOranization_id().isEmpty()) {
				sb.append(" and t.oranization_id="+sysUserVo.getOranization_id());
			}
		}
		String sql = "SELECT  t.id,  t.username,  t.name,  t.phone,  t.password,  t.sex,  t.age,  t.sjbcrq,  t.user_type,  t.status,  t.oranization_id,  s.name AS organizationName,  wmsys.wm_concat(o.name) AS rolesList FROM  comm_sys_USER t LEFT JOIN comm_sys_user_role r ON t.id = r.user_id LEFT JOIN comm_sys_role o ON r.role_id = o.id LEFT JOIN bm_organization s ON s.id = t.oranization_id "+sb.toString()+" GROUP BY   t.id,  t.username,  t.name,  t.phone,  t.password,  t.sex,  t.age,  t.sjbcrq,  t.user_type,  t.status,  t.oranization_id,  s.name ORDER BY  t.sjbcrq ASC";
		
		Page<SysUserVo> page = new Page<>(sql, pageEntity.getPage(), pageEntity.getRows(), commjdbcTemplate, SysUserVo.class);
		return page;
	}

	@Override
	public SysUserVo getSysUserById(String id) {
		String sql = "SELECT  t.id,  t.username,  t.name,  t.phone,  t.password,  t.sex,  t.age,  t.sjbcrq,  t.user_type,  t.status,  t.oranization_id,  s.name AS organizationName, wmsys.wm_concat(o.id) AS roleIds FROM  comm_sys_USER t LEFT JOIN comm_sys_user_role r ON t.id = r.user_id LEFT JOIN comm_sys_role o ON r.role_id = o.id LEFT JOIN bm_organization s ON s.id = t.oranization_id where t.id = ? GROUP BY   t.id,  t.username,  t.name,  t.phone,  t.password,  t.sex,  t.age,  t.sjbcrq,  t.user_type,  t.status,  t.oranization_id,  s.name";
		SysUserVo sysUservo = commjdbcTemplate.queryForObject(sql,
				new BeanPropertyRowMapper<SysUserVo>(SysUserVo.class),
				new Object[] { id });
		return sysUservo;
	}
	@Override
	public String getUserid(){
		String id = commjdbcTemplate.queryForObject("select seq_comm_sys_user.nextval from dual", String.class);
		return id;
	}
	@Override
	public boolean saveSysUser(SysUser sysUser) {
		int count = baseDao.insert(commjdbcTemplate, "comm_sys_user",
				SysUser.class, sysUser);
		return count >= 1 ? true : false;
	}

	@Override
	public boolean removeSysUserById(String ids) {
		String sql = "delete from comm_sys_user where id in (?)";
		int count = commjdbcTemplate.update(sql, new Object[] { ids });
		return count >= 1 ? true : false;
	}

	@Override
	public boolean updateSysUserById(SysUser sysUser) {
		int count = baseDao.update(commjdbcTemplate, "comm_sys_user", SysUser.class, sysUser, sysUser.getId());
		return count >= 1 ? true : false;
	}

	@Override
	public List<SysUser> getByLoginName(String loginName) {
		String sql = "select user_type,id,username,password,salt,name,sex,age,phone,status,oranization_id,sjbcrq,sjxgrq from comm_sys_user where username = ?";
		List<SysUser> sysUser = commjdbcTemplate.query(sql,
				new BeanPropertyRowMapper<SysUser>(SysUser.class),
				new Object[] { loginName });
		return sysUser;
	}

	@Override
	public boolean updateSysUserPwd(String[] str) {
		String sql="update comm_sys_user set  password = ?,  salt = ?,sjxgrq = sysdate where id = ?";
		int count = commjdbcTemplate.update(sql, str);
		return count >= 1 ? true : false;
	}

	@Override
	public List<SysUser> getByLoginNameUpdate(String username,String ymc) {
		String sql = "select user_type,id,username,password,salt,name,sex,age,phone,status,oranization_id,sjbcrq,sjxgrq from comm_sys_user where username = ? and username !=?";
		List<SysUser> sysUser = commjdbcTemplate.query(sql,
				new BeanPropertyRowMapper<SysUser>(SysUser.class),
				new Object[] { username,ymc });
		return sysUser;
	}

}
