package com.mk.dao.resource;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.transaction.annotation.Transactional;

import com.mk.domain.resource.SysResource;

@Mapper
public interface SysResourceDao {
	/**
	 * 获取用户id对应的资源
	 * @param userid
	 * @return
	 */
	public List<SysResource> listRessourceByUserid(String userid);

	public List<SysResource> listAllResource(String resource_type);

	public List<SysResource> listAllMenu();

	public List<SysResource> listTreeGrid();

	public boolean saveResource(SysResource sysResource);

	@Transactional
	public boolean removeResource(String id);

	public SysResource getSysResourceById(String id);

	public boolean updateSysResourceById(SysResource sysResource);

	public List<SysResource> loadtree(Map<String, String> map);
}
