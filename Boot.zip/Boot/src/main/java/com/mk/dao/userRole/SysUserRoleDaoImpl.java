package com.mk.dao.userRole;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mk.base.dao.BaseDao;
import com.mk.domain.userRole.SysUserRole;


@Repository
public class SysUserRoleDaoImpl implements SysUserRoleDao {
	@Autowired
	@Qualifier("commJdbcTemplate")
	protected JdbcTemplate commjdbcTemplate;
	BaseDao baseDao = new BaseDao<>();

	@Override
	public boolean saveUserRole(List<SysUserRole> sysUserRoles) {
		final List<SysUserRole> vos = sysUserRoles;
		final String sql_seq = "select seq_comm_sys_user_role.nextval from dual";
		String sql = "insert into comm_sys_user_role( id,user_id,role_id) values(?,?,?)";
		int[] count = commjdbcTemplate.batchUpdate(sql,
				new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i)
							throws SQLException {
						ps.setString(1, commjdbcTemplate.queryForObject(
								sql_seq, String.class));
						ps.setString(2, vos.get(i).getUser_id());
						ps.setString(3, vos.get(i).getRole_id());
					}

					@Override
					public int getBatchSize() {
						return vos.size();
					}
				});
		return count.length >= 1 ? true : false;
	}

	@Override
	public boolean deleteUserRoleByUserId(String userId) {
		String sql = "delete from comm_sys_user_role where user_id = ?";
		int count = commjdbcTemplate.update(sql, new Object[] { userId });
		return count >= 1 ? true : false;
	}

	@Override
	public Map<String, Set> getRescourceUrlByUserid(String userId) {
		String sql = "SELECT DISTINCT s.url as url FROM comm_sys_role r LEFT JOIN comm_sys_role_resource e ON r.id = e.role_id LEFT JOIN comm_sys_resource s ON e.resource_id = s.id WHERE r.id IN (select role_id AS roleId from comm_sys_user_role where user_id = ?)";
		List<String> strs = (List<String>) commjdbcTemplate.queryForList(sql,
				new Object[] { userId }, String.class);

		Map<String, Set> map = new HashMap<String, Set>();
		Set<String> setUrl = new HashSet<>();
		for (String str : strs) {
			if (str != null && !str.isEmpty()) {
				setUrl.add(str);
			}
		}
		map.put("urls", setUrl);
		return map;
	}

	@Override
	public Map<String, Set> getRoleByUserid(String userId) {
		String sql = "select r.name from comm_sys_user_role ur left join comm_sys_role r on ur.role_id = r.id where ur.user_id = ?";
		List<String> strs = (List<String>) commjdbcTemplate.queryForList(sql,
				new Object[] { userId }, String.class);

		Map<String, Set> map = new HashMap<String, Set>();
		Set<String> setRole = new HashSet<>();
		for (String str : strs) {
			if (str != null && !str.isEmpty()) {
				setRole.add(str);
			}
		}
		map.put("roles", setRole);
		return map;
	}

}
