package com.mk.dao.user;

import java.util.HashMap;
import java.util.List;

import com.mk.domain.user.SysUser;
import com.mk.domain.user.vo.SysUserVo;
import com.mk.tools.Page;


public interface SysUserDao {
	/**
	 * 查询所有的用户信息
	 * 
	 * @return
	 */
	public Page listSysUser(HashMap<String, Object> hashMap);

	/**
	 * 根据ID获取对应的用户信息
	 * 
	 * @param id
	 * @return
	 */
	public SysUserVo getSysUserById(String id);

	/**
	 * 从seq获取userid
	 * 
	 * @return
	 */
	public String getUserid();

	/**
	 * 查询用户名是否存在
	 * 
	 * @param loginName
	 * @return
	 */
	public List<SysUser> getByLoginName(String loginName);

	/**
	 * 插入用户信息
	 * 
	 * @param sysRole
	 * @return
	 */
	public boolean saveSysUser(SysUser sysUser);

	/**
	 * 根据id删除对应的用户信息
	 * 
	 * @param ids
	 * @return
	 */
	public boolean removeSysUserById(String ids);

	/**
	 * 根据id更新用户信息
	 * 
	 * @param sysRole
	 * @return
	 */
	public boolean updateSysUserById(SysUser sysUser);
	/**
	 * 修改密码
	 * @param str
	 * @return
	 */
	public boolean updateSysUserPwd(String[] str);
	/**
	 * 修改校验
	 * @param username
	 * @return
	 */
	public List<SysUser> getByLoginNameUpdate(String username,String ymc);

}
