package com.mk.domain.alibaba_excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;

/**
 * alibaba的easyexcel实体
 * @author Hmk
 * 2019年4月4日下午5:14:22
 */
public class EasyExcel extends BaseRowModel{

	@ExcelProperty(value="姓名",index=0)
	private String name;
	@ExcelProperty(value="性别",index=1)
	private String gender;
	@ExcelProperty(value="年龄",index=2)
	private int age;
	@ExcelProperty(value="住址",index=3)
	private String address;
	
	
	public EasyExcel(String name, String gender, int age, String address) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "EasyExcel [name=" + name + ", gender=" + gender + ", age=" + age + ", address=" + address + "]";
	}
	
	
}
