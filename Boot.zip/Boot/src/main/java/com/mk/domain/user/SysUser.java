package com.mk.domain.user;

public class SysUser {
	private String user_type;//用户类型0系统管理员 1普通授权用户VARCHAR2
	private String id;//主键VARCHAR2
	private String username;//登录名VARCHAR2
	private String password;//密码VARCHAR2
	private String salt;//（加密用）VARCHAR2
	private String name;//姓名VARCHAR2
	private String sex;//性别(0男，1女)CHAR
	private String age;//年龄VARCHAR2
	private String phone;//联系电话VARCHAR2
	private String status;//用户状态（0停用1正常）CHAR
	private String oranization_id;//部门idVARCHAR2
	private String sjbcrq;//数据保存时间DATE
	private String sjxgrq;//数据修改时间DATE
	private String credentialsSalt;
	
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getOranization_id() {
		return oranization_id;
	}
	public void setOranization_id(String oranization_id) {
		this.oranization_id = oranization_id;
	}
	public String getSjbcrq() {
		return sjbcrq;
	}
	public void setSjbcrq(String sjbcrq) {
		this.sjbcrq = sjbcrq;
	}
	public String getSjxgrq() {
		return sjxgrq;
	}
	public void setSjxgrq(String sjxgrq) {
		this.sjxgrq = sjxgrq;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCredentialsSalt() {
		return this.username+this.salt;
	}
	
	

}
