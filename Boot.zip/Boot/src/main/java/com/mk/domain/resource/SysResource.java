package com.mk.domain.resource;

import java.io.Serializable;

public class SysResource implements Serializable {
	private String id;//主键idVARCHAR2
	private String name;//资源名称VARCHAR2
	private String url;//资源路径VARCHAR2
	private String openMode;//打开方式 ajax iframeVARCHAR2
	private String description;//资源介绍VARCHAR2
	private String iconCls;//资源图标VARCHAR2
	private String pid;//父级资源idVARCHAR2
	private String seq;//排序VARCHAR2
	private String status;//状态0停用1启用VARCHAR2
	private String opened;//打开状态0收起1打开VARCHAR2
	private String resource_type;//资源类别0页面1按钮VARCHAR2
	private String create_time;//创建时间DATE
	private String update_time;//修改时间DATE
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
			this.iconCls = iconCls;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOpened() {
		return opened;
	}
	public void setOpened(String opened) {
		this.opened = opened;
	}
	public String getResource_type() {
		return resource_type;
	}
	public void setResource_type(String resource_type) {
		this.resource_type = resource_type;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}
	public String getOpenMode() {
		return openMode == null ? "" : openMode;
	}
	public void setOpenMode(String openMode) {
		this.openMode = openMode;
	}

}
