package com.mk.domain.role;

public class SysRole {
	private String id;//idVARCHAR2
	private String name;//角色名VARCHAR2
	private String seq;//排序VARCHAR2
	private String description;//资源介绍VARCHAR2
	private String status;//有效标志（0无效，1有效）CHAR
	private String sjbcrq;//数据保存时间DATE
	private String sjxgrq;//数据修改时间DATE
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSjbcrq() {
		return sjbcrq;
	}
	public void setSjbcrq(String sjbcrq) {
		this.sjbcrq = sjbcrq;
	}
	public String getSjxgrq() {
		return sjxgrq;
	}
	public void setSjxgrq(String sjxgrq) {
		this.sjxgrq = sjxgrq;
	}

}
