package com.mk.domain.easy_poi;

import cn.afterturn.easypoi.excel.annotation.Excel;

/**
 * easypoi实体
 * @author HMK
 * @date 2018年11月28日 下午3:35:08
 */
public class Easypoi {

	@Excel(name="姓名",width=30,height=10)
	private String name;
	@Excel(name="性别",width=30,height=10)
	private String gender;
	@Excel(name="年龄",width=30,height=10)
	private int age;
	@Excel(name="住址",width=30,height=10)
	private String address;
	
	public Easypoi(String name, String gender, int age, String address) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.address = address;
	}
	public Easypoi(){
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Easypoi [name=" + name + ", gender=" + gender + ", age=" + age
				+ ", address=" + address + "]";
	}
	
}
