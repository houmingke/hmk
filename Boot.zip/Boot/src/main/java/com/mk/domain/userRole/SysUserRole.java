package com.mk.domain.userRole;

import java.io.Serializable;

public class SysUserRole implements Serializable{
	private String id;//主键idVARCHAR2
	private String user_id;//用户idVARCHAR2
	private String role_id;//角色idVARCHAR2
	private String yxbz;//有效标志CHAR
	private String sjbcrq;//数据保存日期DATE
	private String sjxgrq;//数据修改日期DATE
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getRole_id() {
		return role_id;
	}
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}
	public String getYxbz() {
		return yxbz;
	}
	public void setYxbz(String yxbz) {
		this.yxbz = yxbz;
	}
	public String getSjbcrq() {
		return sjbcrq;
	}
	public void setSjbcrq(String sjbcrq) {
		this.sjbcrq = sjbcrq;
	}
	public String getSjxgrq() {
		return sjxgrq;
	}
	public void setSjxgrq(String sjxgrq) {
		this.sjxgrq = sjxgrq;
	}

}
