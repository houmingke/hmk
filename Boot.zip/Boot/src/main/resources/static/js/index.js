
/*<![CDATA[*/
var indexMenuZTree;
$(function(){
	 indexMenuZTree = $.fn.zTree.init($("#layout_west_tree"), {
         data: {
             key: {
                 name: "text"
             },
             simpleData: {
                 enable: true,
                 idKey: "id",
                 pIdKey: "pid",
                 rootPId: 1
             }
         },
         async: {
             enable: true,
             url:"resource/tree",
             dataFilter: function (treeId, parentNode, responseData) {
                 if (responseData) {
                     for (var i =0; i < responseData.length; i++) {
                         var node = responseData[i];
                         if (node.state == "open") {
                             node.open = true;
                         }
                     }
                 }
                 return responseData;
             }
         },
         callback: {
             onClick: function(event, treeId, node) {
             	var text='';
             	if(node.showtext!=''&&node.showtext!=null&&node.showtext!='null'){
             		text=node.showtext;
             	}else{
             		text=node.text;
             	}
                 var opts = {
                     title : text,
                     border : false,
                     closable : true,
                     fit : true,
                     iconCls : node.iconCls +' icon-blue'
                 };
                 var url = node.attributes;
                 var aToStr=JSON.stringify(node);
                 if (url && url.indexOf("http") == -1) {
                   // url = /*[[${basePath}]]*/ + '/' + url;
                     url = url;
                 }
                 if (node.openMode == 'iframe') {
                     opts.content = '<iframe src="' + url + '" frameborder="0" style="border:0;width:100%;height:99.5%;"></iframe>';
                     addTab(opts);
                 } else if (url) {
                     //opts.href = url;
                     opts.content = '<iframe src="' + url + '" frameborder="0" style="border:0;width:100%;height:99.5%;"></iframe>';
                     addTab(opts);
                 }
             }
         }
     });
});

/*]]>*/